<?php
$conn=mysqli_connect("localhost","root","","online_notice");
?>