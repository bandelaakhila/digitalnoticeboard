<h2><b>ABOUT US</b></h2>
<h3>Welcome to the NRI institute of technology, Digital Notice Board, a cutting-edge platform designed to revolutionize campus communication. Our mission is to provide a seamless, eco-friendly, and efficient way to share important updates, events, and announcements with the college community.</h3>
